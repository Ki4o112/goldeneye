########################################
# Educational purpose only             #
########################################
# I'm not responsible for your actions #
########################################
SUBSCRIBE:https://www.youtube.com/channel/UCKAmv8p_TRvUNrJlfiB8qBQ


python 2.7.15 works best

====================================================|
git clone https://github.com/EH30/byte-ddos         |
cd byte-ddos                                        |
python byte-ddos.py                                 |
====================================================|
300 Bytes Recommended 1000 bytes might get you're   |
Internet a Bit slow unless you have a good Internet.|
====================================================|


You're Ip is visible

DON'T USE THIS TOOL FOR ILLEGAL PURPOSE
